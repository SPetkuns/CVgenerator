<?php
if (!empty($_POST['sumbit'])) 
	$name = $_POST['name1']; 
	$name = $_POST['name'];
	$surname = $_POST['user_surname'];
	$birth = $_POST['user_birthdate'];
	$mail =$_POST['user_email'];
	$school = $_POST['school'];
	$begin = $_POST['begin'];
	$finish =$_POST['finish'];
	$programm = $_POST['programm'];
	$english1 = $_POST['english1'];
	$english2 = $_POST['english2'];
	$english3 = $_POST['english3'];
	$latvian1 = $_POST['latvian1'];
	$latvian2 = $_POST['latvian2'];
	$latvian3 = $_POST['latvian3'];
	$russian1 = $_POST['russian1'];
	$russian2 = $_POST['russian2'];
	$russian3 = $_POST['russian3'];

// Send mail;
$send_mail = mail ( $mail , "CV" , "CV" );
$uploaddir = 'images/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);


move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);

$servername = "localhost";
$username = "root";
$password = "pass1234";
$dbname = "cvbd";

$conn = new PDO("mysql:host=$server_name;dbname=$dbname",$username,$password);

	$sql = "INSERT INTO cvgenerator (name,surname,birth,email,school,begin,finish,programm,english1,english2,english3,latvian1,latvian2,latvian3,russian1,russian2,russian3) VALUES ('$name','$surname','$birth','$mail','$school','$begin','$finish','$programm','$english1','$english2','$english3','$latvian1','$latvian2','$latvian3','$russian1','$russian2','$russian3')";
	$conn->exec($sql);


require('fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
//Set grey color for lines and background;
$pdf->SetDrawColor(192,192,192);
$pdf->SetFillColor(192,192,192);
// Set font for title
$pdf->SetFont('Arial','B',32);
// Move to 8 cm to the right
$pdf->Cell(80);
// Centered text in a framed 20*10 mm cell and line break
$pdf->Cell(20,10,'CV',0,1,'C');
// Line break additional;
$pdf->Ln();
// Set color for header
$pdf->SetFont('Arial','',16);
// Header cell without border;
$pdf->SetLineWidth(2);
$pdf->MultiCell(0,10,"General information",'B','L');
//General information cells;
//Set font for cell
$pdf->SetFont('Arial','',14);
$pdf->Ln(70);
$pdf->Cell(85,8,"Name, surname",0,0,'R');
//Set font for Bold text;
$pdf->SetFont('Arial','B',14);
$pdf->Cell(85,8,"$name. $surname",0,1,'L');
$pdf->SetFont('Arial','',14);
$pdf->Cell(85,8,"Date of Birth",0,0,'R');
$pdf->Cell(85,8,$birth,0,1,'L');
$pdf->Cell(85,8,"Email",0,0,'R');
//Set fill,font and color for link;
$pdf->SetFillColor(256,256,256);
$pdf->SetFont('Arial','U',14);
$pdf->SetTextColor(30,144,255);
//Set mail function on click;
$pdf->Cell(70,8,$mail,0,1,'L',$send_mail);
$pdf->Ln();
// Set color for header
$pdf->SetFont('Arial','',16);
// Header cell with bottom borderr;
$pdf->SetLineWidth(2);
$pdf->SetTextColor(0,0,0);
$pdf->MultiCell(0,10,"Languages",'B','L');
$pdf->Ln(10);
$pdf->SetFillColor(192,192,192);
$pdf->SetFont('Arial','',14);
$pdf->SetLineWidth(0.3);
//First row
$pdf->Cell(10,8,'',1,0,'R',true);
$pdf->Cell(45,8,"Language",1,0,'L',true);
$pdf->Cell(45,8,"Speaking",1,0,'L',true);
$pdf->Cell(45,8,"Reading",1,0,'L',true);
$pdf->Cell(45,8,"Writing",1,1,'L',true);
//Second row
$pdf->Cell(10,8,'1.',1,0,'C');
$pdf->Cell(45,8,"English",1,0,'L');
$pdf->Cell(45,8,$english1,1,0,'L');
$pdf->Cell(45,8,$english2,1,0,'L');
$pdf->Cell(45,8,$english3,1,1,'L');
// Third row
$pdf->Cell(10,8,'2.',1,0,'C');
$pdf->Cell(45,8,"Latvian",1,0,'L');
$pdf->Cell(45,8,$latvian1,1,0,'L');
$pdf->Cell(45,8,$latvian2,1,0,'L');
$pdf->Cell(45,8,$latvian3,1,1,'L');
// Fourth row
$pdf->Cell(10,8,'3.',1,0,'C');
$pdf->Cell(45,8,"Russian",1,0,'L');
$pdf->Cell(45,8,$russian1,1,0,'L');
$pdf->Cell(45,8,$russian2,1,0,'L');
$pdf->Cell(45,8,$russian3,1,0,'L');
$pdf->Ln(10);
$pdf->SetLineWidth(2);
$pdf->MultiCell(0,10,"Education",'B','L');
$pdf->Ln(10);
//Education blog
$pdf->SetFont('Arial','',14);
$pdf->Cell(70,8,"School",0,0,'R');
//Set font for Bold text;
$pdf->SetFont('Arial','B',14);
$pdf->Cell(70,8,$school[0],0,1,'L');
$pdf->SetFont('Arial','',14);
$pdf->Cell(70,8,"From",0,0,'R');
$pdf->Cell(70,8,$begin[0],0,1,'L');
$pdf->Cell(70,8,"To",0,0,'R');
$pdf->Cell(70,8,$finish[0],0,1,'L');
$pdf->Cell(70,8,"Programm",0,0,'R');
$pdf->Cell(70,8,$programm[0],0,1,'L');
if (count($school)>1) {
	$pdf->Ln(10);
	$pdf->SetFont('Arial','',14);
	$pdf->Cell(70,8,"School",0,0,'R');
	//Set font for Bold text;
	$pdf->SetFont('Arial','B',14);
	$pdf->Cell(70,8,$school[1],0,1,'L');
	$pdf->SetFont('Arial','',14);
	$pdf->Cell(70,8,"From",0,0,'R');
	$pdf->Cell(70,8,$begin[1],0,1,'L');
	$pdf->Cell(70,8,"To",0,0,'R');
	$pdf->Cell(70,8,$finish[1],0,1,'L');
	$pdf->Cell(70,8,"Programm",0,0,'R');
	$pdf->Cell(70,8,$programm[1],0,1,'L');
}
$pdf->Image($uploadfile,70,45,0,-700,"JPG");
$pdf->Output();


?>