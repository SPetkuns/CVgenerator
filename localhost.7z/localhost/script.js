
var c=0; //счётчик количества строк
function addline()
{
	c++; // увеличиваем счётчик строк
	s=document.getElementById('table').innerHTML; // получаем HTML-код таблицы
	s=s.replace(/[\r\n]/g,''); // вырезаем все символы перевода строк
	re=/(.*)(<tr id=.*>)(<\/table>)/gi;
	// это регулярное выражение позволяет выделить последнюю строку таблицы
	s1=s.replace(re,'$2'); // получаем HTML-код последней строки таблицы
	s2=s1.replace(/\[\d+\]/gi,'['+c+']'); // заменяем все цифры к квадратных скобках
	// на номер новой строки
	s2=s2.replace(/(rmline\()(\d+\))/gi,'$1'+c+')');
	// заменяем аргумент функции rmline на номер новой строки
	s=s.replace(re,'$1$2'+s2+'$3');
	// создаём HTML-код с добавленным кодом новой строки
	document.getElementById('table').innerHTML=s;
	// возвращаем результат на место исходной таблицы
	return false; // чтобы не происходил переход по ссылке
}
function rmline(q)
{
	if (c==0) return false; else c--;
	// если раскомментировать предыдущую строчку, то последний (единственный)
	// элемент удалить будет нельзя.
	s=document.getElementById('table').innerHTML;
	s=s.replace(/[\r\n]/g,'');
	re=new RegExp('<tr id="?newline"? nomer="?\\['+q+'.*?<\\/tr>','gi');
	// это регулярное выражение позволяет выделить строку таблицы с заданным номером
	s=s.replace(re,'');
	// заменяем её на пустое место
	document.getElementById('table').innerHTML=s;
	return false;
}
